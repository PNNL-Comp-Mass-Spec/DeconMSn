%test
clear all
clc
load xtest_choose_equally

load Shew1


num_features = 19 ; 
for feature_num = 1:num_features
    min_feature = min(Xtrain(:, feature_num));
    max_feature = max(Xtrain(:, feature_num));
    if (max_feature - min_feature) > 0
        Xtrain(:, feature_num) = (Xtrain(:, feature_num) - min_feature)/(max_feature - min_feature);
    end
end

[ypred,maxi] = svmmultivaloneagainstone(Xtrain,xsup,w,b,nbsv,kernel,kerneloption);
% epsilon = 1e-6;
% diff = abs(ypred - ytrain);
% error = find(diff > 0);
% errcount = size(error);
% (errcount(1)/size(ypred,1))*100

yindice = [] ; 
nbclass = 4 ; 

iapp_train1 = find(yapp_train == 1) ; 
iapp_train2 = find(yapp_train == 2) ; 
iapp_train3 = find(yapp_train == 3) ; 
iapp_train4 = find(yapp_train == 4) ; 

 for j=1:nbclass;
        yindice=[yindice (ypred==j)'];         
 end;
 
col = 2 ; 
mn_class1  = mean(xapp_train(iapp_train1, col)) ; 
std_class1 = std(xapp_train(iapp_train1, col)) ; 
mn_class2  = mean(xapp_train(iapp_train2, col)) ;
std_class2 = std(xapp_train(iapp_train2, col)) ; 
mn_class3  = mean(xapp_train(iapp_train3, col)) ; 
std_class3 = std(xapp_train(iapp_train3, col)) ; 
mn_class4  = mean(xapp_train(iapp_train4, col)) ;
std_class4 = std(xapp_train(iapp_train4, col)) ; 


[na,nb]=size(Xtrain);
ypredmat=reshape(ypred,na,nb);
contourf(xtesta1,xtesta2,ypredmat*2,30);shading flat
style=['x+*'];
color=['kkk'];
hold on
for i=0:nbclass-1
    h=plot(xapp(i*n+1:(i+1)*n,1),xapp(i*n+1:(i+1)*n,2),[style(i+1) color(i+1)]);
    set(h,'LineWidth',2);
    hold on
end; 

h=plot(xapp(pos,1),xapp(pos,2),'ok');
set(h,'LineWidth',2);
axis( [ -4 4 -4 4]);
legend('classe 1','classe 2','classe 3', 'Support Vector');
hold off