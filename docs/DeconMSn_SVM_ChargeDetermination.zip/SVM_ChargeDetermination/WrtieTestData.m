
clear ;
clc ;
load Shew1
fout1 = fopen('C:\data\Dta\ExcelDocs\Test_Data.txt', 'wt');
fout2 = fopen('C:\data\Dta\ExcelDocs\yTest.txt', 'wt');

num_features = size(Xtrain, 2);
for feature_num = 1:num_features
    min_feature = min(Xtrain(:, feature_num));
    max_feature = max(Xtrain(:, feature_num));
    if (max_feature - min_feature) > 0
        Xtrain(:, feature_num) = (Xtrain(:, feature_num) - min_feature)/(max_feature - min_feature);
    end
end

for i = 1: size(Xtrain,1)
    Set = Xtrain(i, :) ;
    for j = 1:num_features
        fprintf(fout1, '%2.16f ', Set(j));        
    end
    fprintf(fout1, '\n');
    fprintf(fout2, '%d\n', ytrain(i));
end