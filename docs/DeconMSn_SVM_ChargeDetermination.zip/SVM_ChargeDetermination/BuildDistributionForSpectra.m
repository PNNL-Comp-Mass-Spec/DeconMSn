function out = BuildDistributionForSpectra()
cc_mass = 1.007825;

cd c:\data\Dta

fid = fopen('file_list.txt');
fout = fopen('C:\data\Dta\ExcelDocs\Dataset_Peak_Distribution.txt', 'wt');
filename = fgets(fid);

prob = [0 0 0 0];
count = 0;
total_dist = [0 0 0 0];

while filename ~= -1
    distribution = [0 0 0 0];
    prob1 = [0 0 0 0];
    fileCh = strcat(filename) ;
    fspectra = fopen(fileCh);
    line = fgets(fspectra);
    value = str2num(line);
    mass = value(1);
    charge = value(2);
    if (charge == 1)
        cd c:\pnl\lte\Proteomics\ChargeDetermination
        scan = GetScanFromFilename(filename);
        cd c:\data\Dta
        count = count + 1;
        parent_mz = (mass/charge) + cc_mass ;        
        line = fgets(fspectra);
        index_mz = 1;
        Mz_list = [];
        Intensity_list = [];
        while(line ~= -1)
            value = str2num(line);
            Mz_list(index_mz) = value(1);
            Intensity_list(index_mz) = value(2) ;
            index_mz = index_mz + 1;
            line = fgets(fspectra);
        end
        line = fgets(fspectra); % for the last space in file
        for i = 1: size(Mz_list,2)
            %if Intensity_list(i) > Intensity_list(i-1) && Intensity_list(i) > Intensity_list(i+1)
            mz = Mz_list(i);
            if (mz <= parent_mz)
                distribution(1) = distribution(1) + 1;
            elseif ((mz > parent_mz) && (mz <= (2*parent_mz)))
                distribution(2) = distribution(2) + 1;
            elseif (mz > (2* parent_mz) && mz < (3 * parent_mz))
                distribution(3) = distribution(3) + 1;
            elseif (mz > (3* parent_mz) && mz < (4 * parent_mz))
                distribution(4) = distribution(4) + 1;
            end
            %end
        end
        fprintf(fout, '%d\t', parent_mz);
        fprintf(fout, '%d\t', scan);        
        for i = 1:4
            fprintf(fout, '%d\t', distribution(i));
        end
        fprintf(fout, '\n');
        total_dist = total_dist + distribution ;
        sum_dist = sum(distribution);
        prob1 = distribution/sum_dist;
        prob = prob + prob1 ;
        

    end

    fclose(fspectra);
    filename = fgets(fid);
end

fclose(fid);
fclose(fout);

total_dist
if(count >0)
    prob = prob /count;
end


% bar(distribution)
out = prob ;

cd c:\pnl\lte\Proteomics\ChargeDetermination
return;




