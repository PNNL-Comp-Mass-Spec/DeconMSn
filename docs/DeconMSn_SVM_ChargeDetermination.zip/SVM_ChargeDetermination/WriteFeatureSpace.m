load Xapp;
load yapp;
fout = fopen('C:\data\Dta\ExcelDocs\Training_Data.txt', 'wt');

num_features = size(Xapp, 2);

for feature_num = 1:num_features
    min_feature = min(Xapp(:, feature_num));
    max_feature = max(Xapp(:, feature_num));
    Xapp(:, feature_num) = (Xapp(:, feature_num) - min_feature)/(max_feature - min_feature);
end


for i = 1: size(Xapp,1)
    Set = Xapp(i, :) ;
    for j = 1:num_features
        fprintf(fout, '%2.16f ', Set(j));
    end
    fprintf(fout, '%d\n', yapp(i));
end