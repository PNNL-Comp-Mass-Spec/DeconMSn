function out = GetXScore(charge, mzs, intensities, parentMz, mLoss)

if nargin<5
    mLoss = 0;
end

parentMz = parentMz - mLoss;
Xscore = 0;
threshold = 5 ;
median_intensity = median(intensities) ; 
intensities = intensities / median_intensity ; 
intensities(intensities < threshold) = 0 ; 

% intensities = sqrt(intensities) ; 
% max_intensity = max(intensities) ; 
% intensities = intensities/ max_intensity ; 

if(charge == 2)  
    for i = 0:parentMz-1
        mzForwardBegin = (parentMz + i) - 0.5;
        mzForwardEnd = (parentMz + i) + 0.5;
        Mforward = find(mzs >= mzForwardBegin & mzs <= mzForwardEnd);
        SumMforward = sum(intensities(Mforward));
        
        mzReverseBegin = (parentMz - i) - 0.5;
        mzReverseEnd = (parentMz - i) + 0.5;
        Mreverse = find(mzs >= mzReverseBegin & mzs <= mzReverseEnd);
        SumMreverse = sum(intensities(Mreverse));
        
        Xscore = Xscore + (SumMforward * SumMreverse);
    end    
end

if (charge == 3)
    for i = 0: parentMz-1
        mzForwardBegin = (3*parentMz - 2*i) - 0.5;
        mzForwardEnd = (3*parentMz - 2*i) + 0.5;
        Mforward = find(mzs >= mzForwardBegin & mzs <= mzForwardEnd);
        SumMforward = sum(intensities(Mforward));
        
        mzForwardBegin2 = (3*parentMz - i)/2 - 0.5;
        mzForwardEnd2 = (3*parentMz - i)/2 + 0.5;
        Mforward2 = find(mzs >= mzForwardBegin2 & mzs <= mzForwardEnd2);
        SumMforward2 = sum(intensities(Mforward2));   
        
            
        mzReverseBegin = (parentMz - i) - 0.5;
        mzReverseEnd = (parentMz - i) + 0.5;
        Mreverse = find(mzs >= mzReverseBegin & mzs <= mzReverseEnd);
        SumMreverse = sum(intensities(Mreverse));
        
        Xscore = Xscore + (SumMforward * SumMreverse) + (SumMforward2 * SumMreverse);
    end
end

out = Xscore;
return;