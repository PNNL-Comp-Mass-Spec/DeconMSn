#include <iostream>
#include <vector>

namespace Engine
{
	namespace ChargeDetermination
	{
		class SupportVectors
