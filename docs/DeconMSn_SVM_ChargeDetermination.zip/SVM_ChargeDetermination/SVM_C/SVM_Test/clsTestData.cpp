#include "clsTestData.h"

XERCES_CPP_NAMESPACE_USE

namespace Engine
{
	namespace ChargeDetermination
	{
		SVMTestData::SVMTestData(void)
		{
			mobj_scan_features = new Engine::ChargeDetermination::FeatureList();	
			mobj_support_features = new Engine::ChargeDetermination::FeatureList();
			strcpy(mchar_file_name, "C:\\data\\Dta\\ExcelDocs\\Test_Data.txt");
			strcpy(mchar_svm_param_file_name,"C:\\data\\Dta\\ExcelDocs\\SVM_Params.dat") ;
			strcpy(mchar_xml_file_name, "svm_params.xml");
			mvect_nbsv.push_back(0) ; 
		}
	
		SVMTestData::~SVMTestData(void)
		{		
			delete mobj_scan_features;
			delete mobj_support_features;
			delete mmat_kernel;
		}

		bool SVMTestData::NormalizeData()
		{
			int num_scans = (int) mvect_xtest.size();
			int num_features = mobj_scan_features->GetNumFeatures();

			//needs to be done, for the time being expecting the feature space to be normalized already
			return true;
		}

		void SVMTestData::ReadData()
		{
			const int MAX_BUFFER_LINE = 512;
			char ch ;
			const int num_features = 19;
			std::vector <double>features;
			double feature_val;
			int row_num = 0 ;

			mobj_scan_features->SetNumFeatures(num_features);
		
			std::ifstream fin(mchar_file_name, std::ios::in);			
			
			while (!fin.eof())
			{
				if (row_num == 451)
					bool debug = true ; 
				
				features.clear() ;
				for(int i=0; i < num_features; i++)
				{
					fin>>feature_val;
					features.push_back(feature_val);					
				}
				row_num++ ; 				
				fin>>ch;				
				mobj_scan_features->InitValues(features);
				mvect_xtest.push_back(*mobj_scan_features);
				
			}
			fin.close();						
		}

		void SVMTestData::ReadSVMParams()
		{
			const int MAX_BUFFER_LINE = 512;
			char* buffer1 = new char[MAX_BUFFER_LINE];
			char* buffer2 = new char[MAX_BUFFER_LINE];

			
			double support_value;
			std::vector <double> vect_xsup;
			double w_value;		
			double nbsv_value; 
			double b_value ; 
			std::fstream fin(mchar_svm_param_file_name);

			if(!fin)
				return ;
			
			char next;	
			
			
			while (!fin.eof())
			{				
				fin.getline(buffer1, MAX_BUFFER_LINE);
				if(strcmp(buffer1, "@xsup") == 0)
				{
					int count = 0;
					next = fin.peek();																				
					while(!fin.eof())
					{					
						count++;
						if(count == 6617)
							bool debug = true;
						int num_features = 19 ;//mobj_support_features->GetNumFeatures();
						vect_xsup.clear();
						for (int feature_num = 0; feature_num <num_features; feature_num++)
						{
							fin>>support_value ;
							vect_xsup.push_back(support_value);
							next = fin.peek();
						}					
						mobj_support_features->InitValues(vect_xsup) ;
						mvect_xsup.push_back(*mobj_support_features);	
						//fin>>next;
					}							
				}
				else if(strcmp(buffer1, "@w") == 0)
				{						
					next = fin.peek();						
					while(next != '\n')
					{	
						fin>>w_value;
						mvect_w.push_back(w_value);							
						next = fin.peek();													
					}								
				}
				else if (strcmp(buffer1, "@b") == 0)
				{
					next = fin.peek();						
					while(next != '\n')
					{	
						fin>>b_value;
						mvect_b.push_back(b_value);							
						next = fin.peek();													
					}									
				}						
				else if (strcmp(buffer1, "@nbsv") == 0)
				{
					next = fin.peek();						
					while(next != '\n')
					{	
						fin>>nbsv_value;
						mvect_nbsv.push_back(nbsv_value);							
						next = fin.peek();													
					}									
				}		
			}
		}

		void SVMTestData::WriteToXml()
		{
			const char* svm_tag = "SVMParams";
			const char* b_tag = "b";
			const char* w_tag = "w";
			const char* nbsv_tag = "nbsv" ; 
			const char* bias_tag = "Bias";
			const char* weights_tag = "Support_Weights";
			const char* support_tag = "Support_Vectors";
			const char* bias_support_tag = "Support_Bias" ; 
			const char* xsup_tag = "xsup";
			const char* feature_tag = "feature";
			
			char buf[100];

			try
			{
				XMLPlatformUtils::Initialize();
			}
			catch(const XMLException &toCatch)
			{
				//Do something
				return;
			}

			DOMImplementation* impl =  DOMImplementationRegistry::getDOMImplementation(XMLString::transcode("Core"));
			DOMWriter         *theSerializer = impl->createDOMWriter();	

			 if (theSerializer->canSetFeature(XMLUni::fgDOMWRTSplitCdataSections, true))
                theSerializer->setFeature(XMLUni::fgDOMWRTSplitCdataSections, true);

            if (theSerializer->canSetFeature(XMLUni::fgDOMWRTDiscardDefaultContent, true))
                theSerializer->setFeature(XMLUni::fgDOMWRTDiscardDefaultContent, true);

            if (theSerializer->canSetFeature(XMLUni::fgDOMWRTFormatPrettyPrint, true))
                theSerializer->setFeature(XMLUni::fgDOMWRTFormatPrettyPrint, true);

            if (theSerializer->canSetFeature(XMLUni::fgDOMWRTBOM, true))
                theSerializer->setFeature(XMLUni::fgDOMWRTBOM, true);

		
			
			if (impl != NULL)
			{

				DOMDocument* doc = impl->createDocument(0, XMLString::transcode(svm_tag), 0);
				DOMElement* rootElem = doc->getDocumentElement();	
				
				DOMElement* biasElem = doc->createElement(XMLString::transcode(bias_tag));
				DOMElement* nbsvElem = doc->createElement(XMLString::transcode(bias_support_tag));								
				DOMElement* weightElem = doc->createElement(XMLString::transcode(weights_tag));
				DOMElement* xsupElem = doc->createElement(XMLString::transcode(xsup_tag));
				DOMElement* supportElem = doc->createElement(XMLString::transcode(support_tag));


				//First the b
				rootElem->appendChild(biasElem);
				for (int i = 0; i < (int)mvect_b.size(); i++)
				{					
					DOMElement *bElemSingle = doc->createElement(XMLString::transcode(b_tag));
					sprintf(buf, "%f", mvect_b[i]);
					DOMText* b_value = doc->createTextNode(XMLString::transcode(buf));
					bElemSingle->appendChild(b_value);
					biasElem->appendChild(bElemSingle);
				}

				//Next the nbsv
				rootElem->appendChild(nbsvElem);
				for (int i = 0; i < (int)mvect_nbsv.size(); i++)
				{					
					DOMElement *nbsvElemSingle = doc->createElement(XMLString::transcode(nbsv_tag));
					sprintf(buf, "%f", mvect_nbsv[i]);
					DOMText* nbsv_value = doc->createTextNode(XMLString::transcode(buf));
					nbsvElemSingle->appendChild(nbsv_value);
					nbsvElem->appendChild(nbsvElemSingle);
				}

				//Next the weights
				rootElem->appendChild(weightElem);
				for (int i = 0; i < (int)mvect_w.size(); i++)
				{					
					DOMElement *wElemSingle = doc->createElement(XMLString::transcode(w_tag));
					sprintf(buf, "%f", mvect_w[i]);
					DOMText* w_value = doc->createTextNode(XMLString::transcode(buf));
					wElemSingle->appendChild(w_value);
					weightElem->appendChild(wElemSingle);
				}
				
				// Nest the vectors
				rootElem->appendChild(supportElem);
				Engine::ChargeDetermination::FeatureList this_xsup;
				for (int i = 0; i < (int) mvect_xsup.size(); i++)
				{					
					this_xsup = mvect_xsup[i];
					DOMElement *xsupSingle = doc->createElement(XMLString::transcode(xsup_tag));					
					int num_features = this_xsup.GetNumFeatures();
					for (int j = 0; j < num_features; j++)
					{
						DOMElement *feature = doc->createElement(XMLString::transcode(feature_tag));
						sprintf(buf, "%f", this_xsup.GetValueAt(j));
						DOMText *feature_value = doc->createTextNode(XMLString::transcode(buf));
						feature->appendChild(feature_value);
						xsupSingle->appendChild(feature);
					}
					supportElem->appendChild(xsupSingle);
				}

				XMLFormatTarget *myFormTarget;
				myFormTarget = new LocalFileFormatTarget(mchar_xml_file_name);
				theSerializer->writeNode(myFormTarget, *doc);
			}
			
			XMLPlatformUtils::Terminate();			
		}

		void SVMTestData::LoadDataFromXml()
		{
												
			static XERCES_CPP_NAMESPACE::XercesDOMParser::ValSchemes    valScheme = XERCES_CPP_NAMESPACE::XercesDOMParser::Val_Never;
			bool	doNamespaces = false;
			bool	doSchema = false;
			bool	schemaFullChecking = false;			
			bool	doCreate = false;
			bool	bFailed = false;

			const char* svm_tag = "SVMParams";
			const char* b_tag = "b";
			const char* w_tag = "w";
			const char* nbsv_tag = "nbsv";
			const char* bias_tag = "Bias";
			const char* weights_tag = "Support_Weights";
			const char* support_tag = "Support_Vectors";
			const char* bias_support_tag = "Support_Bias" ; 
			const char* xsup_tag = "xsup";
			const char* feature_tag = "feature";
			int weight_count = 0;
			int feature_count = 0;
			int support_count = 0;


			
			char *pEnd;
			//Initialize the XML 
			try
			{
				XERCES_CPP_NAMESPACE::XMLPlatformUtils::Initialize();			
			}
			catch(const XERCES_CPP_NAMESPACE::XMLException &toCatch)
			{
				//Do something
				return;
			}

			XERCES_CPP_NAMESPACE::XercesDOMParser *parser = new XERCES_CPP_NAMESPACE::XercesDOMParser;
			if (parser)
			{
				parser->setValidationScheme(valScheme);
				parser->setDoNamespaces(doNamespaces);
				parser->setDoSchema(doSchema);
				parser->setValidationSchemaFullChecking(schemaFullChecking);
				try
				{
					parser->parse(mchar_xml_file_name);				
				}
				catch(const XERCES_CPP_NAMESPACE::XMLException &toCatch)
				{
					throw toCatch.getMessage();
					printf((char*)toCatch.getMessage());
				}

				//create DOM tree
				XERCES_CPP_NAMESPACE::DOMDocument *doc = NULL ;				
				try
				{
					doc = parser->getDocument();				
				}
				catch(const XERCES_CPP_NAMESPACE::XMLException &toCatch)
				{
					throw toCatch.getMessage() ; 
				}
				catch(const XERCES_CPP_NAMESPACE::DOMException &toCatch)
				{
					throw toCatch.getMessage() ; 
				}
				catch(const char *toCatch)
				{
					throw toCatch ; 
				}
				catch(const exception &toCatch)
				{
					throw toCatch.what() ; 
				}
				
							
				XERCES_CPP_NAMESPACE::DOMNode *nRoot = NULL;			

				if (doc)
				{
					//start walking down the tree					
					nRoot = (XERCES_CPP_NAMESPACE::DOMNode*) doc->getDocumentElement();	
					char *rootName = XERCES_CPP_NAMESPACE::XMLString::transcode(nRoot->getNodeName()); // svm_params
					XERCES_CPP_NAMESPACE::DOMNode *nCurrent = NULL;						
					XERCES_CPP_NAMESPACE::DOMTreeWalker *walker = doc->createTreeWalker(nRoot, XERCES_CPP_NAMESPACE::DOMNodeFilter::SHOW_ELEMENT, NULL, false); //at elements
					
					nCurrent = walker->nextNode(); //first bias

					while(nCurrent!=0)
					{
						char *nName = XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getNodeName());
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, bias_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, b_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							double b = strtod(XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getTextContent()), &pEnd);	
							mvect_b.push_back(b) ;
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, bias_support_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, nbsv_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							double nbsv = strtod(XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getTextContent()), &pEnd);	
							mvect_nbsv.push_back(nbsv) ;
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, weights_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, w_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							double w = strtod(XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getTextContent()), &pEnd);	
							mvect_w.push_back(w);
							nCurrent = walker->nextNode();
							weight_count++;
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, support_tag))
						{
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);													
							nCurrent = walker->nextNode();
							continue;
						}
						if (XERCES_CPP_NAMESPACE::XMLString::equals(nName, xsup_tag))
						{
							std::vector <double> vect_xsup;
							XERCES_CPP_NAMESPACE::XMLString::release(&nName);	
							nCurrent = walker->nextNode();
							nName = XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getNodeName());
							feature_count = 0;
							while (XERCES_CPP_NAMESPACE::XMLString::equals(nName, feature_tag))
							{
								XERCES_CPP_NAMESPACE::XMLString::release(&nName);
                                double feature = strtod(XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getTextContent()), &pEnd);	
								vect_xsup.push_back(feature);
								nCurrent = walker->nextNode();
								if (nCurrent!=0)
									nName = XERCES_CPP_NAMESPACE::XMLString::transcode(nCurrent->getNodeName());
								else
									nName = NULL;
								feature_count++;
							}
							mobj_support_features->InitValues(vect_xsup) ;
							mvect_xsup.push_back(*mobj_support_features);
							support_count++;
							continue;
						}
					}
				}
			}
			XERCES_CPP_NAMESPACE::XMLPlatformUtils::Terminate();
		}

		void SVMTestData::TestDataSet()
		{
				
			int length_nbsv = 0 ; 
			int num_class = 0;
			int num_test = 0 ; 
			int num_iterations = 6 ; 
			int k = 0;
			//double **mat_vote_val ; 


			length_nbsv = mvect_nbsv.size() ;
			num_class = 4 ; //(int)(1 + (int)(sqrt(1+4*2*length_nbsv)))/2 ; 
			num_test = (int) mvect_xtest.size() ; 
			mmat_vote = matrix_allocate(num_test, num_class, sizeof(double)) ; 
			mat_vote_val = (double **) mmat_vote->ptr ;
			mmat_discriminant_scores = matrix_allocate(num_test, num_iterations, sizeof(double)); 
			mat_discriminant_scores_val = (double **) mmat_discriminant_scores->ptr ; 
			CalculateCumSum() ; 

			for (int row = 0; row < mvect_xtest.size(); row++)
				mvect_ypredict.push_back(0) ; 

			for (int row = 0; row < mmat_vote->rows ; row++)
			{
				for(int col = 0; col < mmat_vote->cols ; col++)
				{
					mat_vote_val[row][col] = 0 ; 
				}
				for (int col = 0; col < mmat_discriminant_scores->cols ; col++)
				{
					mat_discriminant_scores_val[row][col] = 0 ; 
				}
			}

			int iter_num = 0 ; 

			for(int i = 0; i < num_class; i++)
			{
				for (int j = i+1; j < num_class; j++)
				{
					int startIndexToConsider = mvect_aux[k]; 					
					int stopIndexToConsider = (mvect_aux[k] + mvect_nbsv[k+1]) - 1 ; 
					SVMClassification(startIndexToConsider, stopIndexToConsider, k) ; 
					for (int row = 0; row < mmat_vote->rows; row++)
					{
						if (row == 54)
							bool debug = true ; 
						double val = mvect_ypredict[row];
						mat_discriminant_scores_val[row][iter_num] = val ; 			
						mvect_ypredict[row] = 0 ; 
						if (val >= 0) 
						{
							double val2 = mat_vote_val[row][i] ;
							val2++;
							mat_vote_val[row][i] = val2 ; 
						}
						else
						{
							double val1 = mat_vote_val[row][j] ;
							val1++ ; 
							mat_vote_val[row][j] = val1 ;
						}
					}					
					k++;
					iter_num ++ ; 
				}
			}
		}

		void SVMTestData::CalculateCumSum()
		{
			double sum = 0;
			for (int i = 0; i < mvect_nbsv.size(); i++)
			{
				sum = 0 ; 				
				for (int j = 0 ; j <= i ; j++)
				{
					sum += mvect_nbsv[j] ; 
				}
				mvect_aux.push_back(sum) ; 
			}
		}

		void SVMTestData::SVMClassification(int startIndex, int stopIndex, int k_bias)
		{
			std::vector<double> span;
			std::vector<double> y;
			std::vector <Engine::ChargeDetermination::FeatureList> chunk_xtest;
			std::vector <Engine::ChargeDetermination::FeatureList> chunk_xsup;
			Engine::ChargeDetermination::FeatureList this_test_vector;
			Engine::ChargeDetermination::FeatureList this_support_vector;			
			
			int num_support = stopIndex - startIndex;
			int num_test = (int)mvect_xtest.size();
			const int chunksize = 100;
			std::vector<int> ind1;
			std::vector<int> ind2;
						
			int chunks1 = int(num_support/chunksize)+1;
			int chunks2 = int(num_test/chunksize)+1;
			
			
			// Performing y2(ind2)=y2(ind2)+ kchunk*w(ind1) ;	
			for(int ch1 = 1; ch1 <= chunks1; ch1++)
			{
				//Get ind1
				int low_ind1_index = (ch1-1)*chunksize + startIndex;
				int high_ind1_index = (ch1*chunksize) - 1 + startIndex;				
				if(high_ind1_index > stopIndex)					
					high_ind1_index = stopIndex; 
				ind1.clear();
				for(int index = 0; index <= (high_ind1_index-low_ind1_index); index++)
					ind1.push_back(index + low_ind1_index);					

				//Get support vectors
				chunk_xsup.clear();
				for (int j = 0; j < (int)ind1.size(); j++)
				{
					int xsupIndex = ind1[j];					
					this_support_vector = mvect_xsup[xsupIndex];					
					chunk_xsup.push_back(this_support_vector);
				}
				
				for(int ch2 = 1; ch2 <= chunks2; ch2++)
				{
				
					//Get ind2
					int low_ind2_index = (ch2-1)*chunksize ;
					int high_ind2_index = (ch2*chunksize) - 1;
					if(high_ind2_index > num_test)
						high_ind2_index=num_test-1;		
					ind2.clear();
					for (int index2 = 0; index2<=(high_ind2_index-low_ind2_index); index2++)
						ind2.push_back(index2 + low_ind2_index);			

					 //Get X vector
					chunk_xtest.clear();
					for(int j=0; j< (int)ind2.size(); j++)
					{
						int xIndex = ind2[j];						
						this_test_vector = mvect_xtest[xIndex];
						chunk_xtest.push_back(this_test_vector);						
					}

					//Get the kernel										
					MATRIX *svm_kernel;
					double **svm_kernel_val;
					svm_kernel = GetKernel(chunk_xtest, chunk_xsup);
					svm_kernel_val = (double **) svm_kernel->ptr;
			
					
					//Read in the weights w(ind1)
					MATRIX *w;
					double **w_value;
					w = matrix_allocate((int)ind1.size(), 1, sizeof(double));
					w_value = (double **) w->ptr;					
					for (int i=0; i<(int)ind1.size(); i++)
					{
						int index = ind1[i];
						w_value[i][0] = mvect_w[index];						
					}
					
					// m1 = kchunk*w(ind1)
					MATRIX *m1;					
					double **m1_value;										
					m1 = matrix_mult(svm_kernel, w);
					m1_value = (double**)m1->ptr;
					
					
					//y2(ind2) += m1;							
					for(int i = 0; i < (int)ind2.size(); i++)
					{
						int index = ind2[i];
						mvect_ypredict[index]+= m1_value[i][0];		
					}		

					
					matrix_free(m1);
					matrix_free(svm_kernel);
					matrix_free(w);
				}
				
			}			
			
			//Add w0			
			for (int i = 0; i < (int) mvect_ypredict.size(); i++)
			{				
				mvect_ypredict[i]+= mvect_b[k_bias];
				double debug = mvect_ypredict[i];
				debug++;
			}
		
		}

		void SVMTestData::TestResult()
		{
			char yFile[256];
			const int MAX_BUFFER_SIZE = 512;
			char buffer[MAX_BUFFER_SIZE];
			int diff[1000];

			strcpy(yFile,"C:\\data\\Dta\\ExcelDocs\\yTest.txt") ;
			std::ifstream fin(yFile, std::ios::in);		
			std::ofstream fout("C:\\data\\Dta\\ExcelDocs\\SVM_C_Charges.txt") ; 

			int cls;
			std::vector<int> yActual;
			bool debug ; 

			while (!fin.eof())
			{
				fin>>cls;
				yActual.push_back(cls);
				fin.getline(buffer, MAX_BUFFER_SIZE);
			}
	
			int num_rows; 
			num_rows = mmat_vote->rows ;
			if(mmat_vote->rows != yActual.size())
				debug = true;

			// double **mat_vote_val ; 
			 //mat_vote_val = (double **) mmat_vote->ptr ;

			 int count = 0;
			 double error = 0;
			 int both = 0;
			 int charge;
			 std::vector <int> c_charge ; 

			 for (int i = 0; i < mmat_vote->rows; i++)
			 {	
				int predict_charge = 1 ; 				
				if (i == 816)
					bool debug = true; 
				
				for (int col = 0 ; col < mmat_vote->cols ; col++)
				{
					int rank = mat_vote_val[i][col] ; 
					if (rank == 3)
					{
						predict_charge = col + 1 ; 
						break ; 
					}
				}

				c_charge.push_back(predict_charge); 
				fout<<predict_charge<<std::endl ; 
				int real_charge = yActual[i];
				if (predict_charge != real_charge)
				{
					count++;					
				}
			}

			fin.close() ;
			fout.close() ; 

			/*for (int i = 0; i < 1000; i++)
			{
				int ind = diff[i];
				ind++;
			}*/

			std::vector <int> matlab_charge ; 
			char chargeFile[256] ; 
			strcpy(chargeFile,"C:\\PNL\\Proteomics\\ChargeDetermination\\SVM_C\\matlab_charge.csv") ;
			std::fstream fin1(chargeFile, std::ios::in);
			
			int inp_charge ; 					
			/*while (!fin1.eof())
			{
				fin1>>inp_charge;				
				matlab_charge.push_back(inp_charge) ; 
				fin1.getline(buffer, MAX_BUFFER_SIZE);

			}
			
			int charge_list_size = matlab_charge.size() ; 
			for (int i = 0 ; i < charge_list_size-1; i++)
			{
				if (c_charge[i] != matlab_charge[i])
				{
					int ccharge = c_charge[i] ; 
					int mcharge = matlab_charge[i] ; 
					bool debug = true; 
				}
			}
				*/
				
			
		    error = ((double)count/(double)mmat_vote->rows)*100;
			std::cerr<<"Error is :\t"<<error ; 
		}
			
		


		MATRIX *SVMTestData::GetKernel(std::vector<Engine::ChargeDetermination::FeatureList> &vect_xtest, std::vector<Engine::ChargeDetermination::FeatureList> &vect_xsup)
		{
			Engine::ChargeDetermination::FeatureList this_test_vector;
			Engine::ChargeDetermination::FeatureList this_support_vector;

			MATRIX *norm_x;
			MATRIX *norm_xsup;	
			MATRIX *norm_xsup_t;
			MATRIX *metric;
			MATRIX *xsup;
			MATRIX *xsup_t;
			MATRIX *xsup2;
			MATRIX *x;
			MATRIX *x2;
			MATRIX *ps;
			MATRIX *psTemp;			
			MATRIX *m1;
			MATRIX *m2;
			MATRIX *m3;
			MATRIX *kernel;

			double **norm_x_value;
			double **norm_xsup_value;
			double **metric_value;
			double **xsup_value;			
			double **x_value;
			double **x2_value;
			double **ps_value;			
			double **kernel_value;
			double **m1_value;
			double **m2_value;
			double **m3_value;
			

			int num_features = mobj_scan_features->GetNumFeatures();
			int num_vectors = (int)vect_xsup.size();
			int num_test = (int) vect_xtest.size();
			int ps_rows;
			int ps_cols;

			//get vectors
			xsup = matrix_allocate(num_vectors, num_features, sizeof(double));			
			xsup_value = (double **)xsup->ptr;
			for (int i = 0; i <num_vectors;i++)
			{
				this_support_vector = vect_xsup[i];
				for (int j = 0; j < num_features; j++)
				{
					double val_sup = this_support_vector.GetValueAt(j);				
					xsup_value[i][j] = val_sup;
				}
			}
			
			x = matrix_allocate(num_test, num_features, sizeof(double));
			x_value = (double **)x->ptr;				
			for (int i = 0; i <num_test;i++)
			{
				this_test_vector = vect_xtest[i];				
				for (int j = 0; j < num_features; j++)
				{
					double val_x= this_test_vector.GetValueAt(j);					
					x_value[i][j] = val_x;
				}
			}
		
			//Init metric
			metric = matrix_allocate(num_features, num_features, sizeof(double));
			metric_value = (double**)metric->ptr;
			for (int i = 0; i < num_features; i++)
				metric_value[i][i] = 1;

			// Get ps
			m1 = matrix_mult(x, metric);
			m1_value = (double **)m1->ptr;			
			xsup_t = matrix_transpose(xsup);
			double **xsup_t_value;
			xsup_t_value = (double **) xsup_t->ptr;

			/*double temp1[17];
			double temp2[100];
			double sum =0;*/

			/*for(int h = 0; h < m1->cols; h++)
				temp1[h] = m1_value[79][h];
			for (int h = 0; h < xsup_t->rows;h++)
				temp2[h] = xsup_t_value[h][25];

			for (int h = 0; h <17; h++)
				sum = sum + temp1[h]*temp2[h];*/

			ps = matrix_mult(m1, xsup_t); 
			double **ps_v;
			ps_v = (double **) ps->ptr;
			ps_rows = ps->rows; //num_test
			ps_cols = ps->cols; //num_support
			
						
			// Get norms           
			norm_x = matrix_allocate(ps_rows, ps_cols, sizeof(double));
			norm_x_value = (double **)norm_x->ptr;

			norm_xsup = matrix_allocate(ps_cols, ps_rows, sizeof(double));
			norm_xsup_value = (double **)norm_xsup->ptr;
						
			x2 = matrix_mult_pwise(x, x);
			x2_value = (double **) x2->ptr;
			m2 = matrix_mult(x2, metric);
			m2_value = (double **)m2->ptr;

			for(int row_num = 0; row_num <m2->rows; row_num++)
			{
				double sumX = 0;		
				for(int col_num = 0; col_num < m2->cols; col_num++)
				{
					double val_m2 = m2_value[row_num][col_num];					
					sumX = sumX + val_m2 ;										
				}		
				//This is for ease of matrix addition
				for (col_num=0; col_num < norm_x->cols; col_num++)
                    norm_x_value[row_num][col_num] = sumX;
			}

			xsup2 = matrix_mult_pwise(xsup, xsup);
			m3 = matrix_mult(xsup2, metric);
			m3_value = (double **)m3->ptr;
			for(int row_num = 0; row_num < m3->rows; row_num ++)
			{
				double sumXsup = 0;
				for(int col_num = 0; col_num < m3->cols; col_num++)
				{
					double val_m3 = m3_value[row_num][col_num];
					sumXsup = sumXsup+val_m3;		
				}		
				
				for(int col_num = 0; col_num < norm_xsup->cols; col_num++)
					norm_xsup_value[row_num][col_num] = sumXsup;
			}
			
			norm_xsup_t = matrix_transpose(norm_xsup);
			double **norm_xsup_t_val;
			norm_xsup_t_val = (double **) norm_xsup_t->ptr;

			double scale = -2.0;
            psTemp = matrix_scale(ps, scale);
			double **psTemp_val;
			psTemp_val = (double **) psTemp->ptr;
			
			MATRIX *ps2;
			MATRIX *ps3;			
			ps2 = matrix_add(psTemp, norm_x);
			double **ps2_val;
			ps2_val = (double **) ps2->ptr;
			ps3 = matrix_add(ps2, norm_xsup_t);
			double **ps3_val;
			ps3_val = (double **) ps3->ptr;

			matrix_free(ps);
			ps = matrix_scale(ps3, 1/scale);
			ps_value = (double **) ps->ptr;
			matrix_free(psTemp);
			matrix_free(ps2);
			matrix_free(ps3);

			kernel = matrix_allocate(ps->rows, ps->cols,ps->element_size);
			kernel_value = (double **)kernel->ptr;

			for (int row_num = 0; row_num < ps->rows; row_num ++)
			{
				for(int col_num = 0; col_num < ps->cols; col_num++)
				{
					double val = ps_value[row_num][col_num];
					double eval = exp(val);
					kernel_value[row_num][col_num] = eval;
				}
			}

		 
			matrix_free(norm_x);
			matrix_free(norm_xsup);	
			matrix_free(norm_xsup_t);
			matrix_free(metric);
			matrix_free(xsup);
			matrix_free(xsup_t);
			matrix_free(xsup2);
			matrix_free(x);
			matrix_free(x2);
			matrix_free(ps);
			//matrix_free(ps1);			
			matrix_free(m1);
			matrix_free(m2);
			matrix_free(m3);	

			return (kernel) ; 
		}

	}
}