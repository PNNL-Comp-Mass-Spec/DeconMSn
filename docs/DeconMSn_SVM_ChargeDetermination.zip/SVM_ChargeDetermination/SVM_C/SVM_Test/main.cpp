#include <iostream>
#include <fstream>
#include "clsTestData.h"

int main( int argc, char **argv)
{

	Engine::ChargeDetermination::SVMTestData *SVMTest;

	SVMTest = new Engine::ChargeDetermination::SVMTestData();
	//SVMTest->ReadSVMParams();
	//SVMTest->WriteToXml();
	SVMTest->LoadDataFromXml();
	SVMTest->ReadData();

	//SVMTest->NormalizeData
	SVMTest->TestDataSet();
	SVMTest->TestResult();

	return 0;
}

