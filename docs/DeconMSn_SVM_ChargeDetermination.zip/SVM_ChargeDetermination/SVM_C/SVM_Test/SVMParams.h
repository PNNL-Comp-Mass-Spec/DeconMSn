#include <iostream>
#include <vector>

namespace Engine
{
	namespace ChargeDetermination
	{
		class SVM_Parameters
		{
			
			public:
				

				SVM_Parameters(void);
				~SVM_Parameters(void);				
		};
	}
}
	
		