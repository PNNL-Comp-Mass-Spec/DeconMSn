#include "FeautureSpace.h"

namespace Engine
{
	namespace ChargeDetermination
	{
		FeatureList::FeatureList(void)
		{
			mint_num_features = 19;
			for(int feature_num = 0; feature_num < mint_num_features; feature_num ++)
				mvect_features.push_back(0);
		}			
		
		FeatureList::~FeatureList(void)
		{
			mvect_features.empty();
		}

		void FeatureList::InitValues(std::vector<double> &features)
		{
			for(int feature_num = 0 ; feature_num < mint_num_features; feature_num++)
				mvect_features[feature_num] = features[feature_num];
		}

		void FeatureList::SetNumFeatures(int num_features)
		{
			mint_num_features = num_features;
		}
		
		int FeatureList::GetNumFeatures()
		{
			return mint_num_features;
		}
		double FeatureList::GetValueAt(int index)
		{
			return mvect_features[index];
			
		}

	}
}
