#include <iostream>
#include <fstream>
#include <math.h>
#include "FeautureSpace.h"
#include "SVMParams.h"
#include "..\Matrix.h"
#include <vector>
#include <string>
#include"..\Matrix.h"
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/parsers/AbstractDOMParser.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMImplementationRegistry.hpp>
#include <xercesc/dom/DOMWriter.hpp>
#include <xercesc/dom/DOMBuilder.hpp>
#include <xercesc/dom/DOMException.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMEntity.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMError.hpp>
#include <xercesc/dom/DOMLocator.hpp>
#include <xercesc/dom/DOMNamedNodeMap.hpp>
#include <xercesc/dom/DOMNode.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMText.hpp>
#include <xercesc/dom/DOMAttr.hpp>
#include <xercesc/dom/DOMTreeWalker.hpp>
#include <xercesc/dom/DOMErrorHandler.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>
#include <xercesc/util/XercesDefs.hpp>
#include <xercesc/util/TransService.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>



namespace Engine
{
	namespace ChargeDetermination
	{
		class SVMTestData
		{

			char mchar_file_name[256];
			char mchar_svm_param_file_name[256];
			char mchar_xml_file_name[256];

			std::vector <double> mvect_w;
			std::vector <double> mvect_b ; 
			std::vector <double> mvect_nbsv ; 			
			std::vector <double> mvect_ypredict;
			std::vector <double> mvect_aux ; 
			MATRIX *mmat_vote ;
			double ** mat_vote_val ; 
			MATRIX *mmat_discriminant_scores ; 
			double ** mat_discriminant_scores_val ; 

			Engine::ChargeDetermination::FeatureList *mobj_scan_features;
			std::vector<Engine::ChargeDetermination::FeatureList> mvect_xtest;			

			Engine::ChargeDetermination::FeatureList *mobj_support_features;
			std::vector <Engine::ChargeDetermination::FeatureList> mvect_xsup ;


			Engine::ChargeDetermination::SVM_Parameters *mobj_svm_params;

			MATRIX *mmat_kernel;

			public:
				void ReadData();
				bool NormalizeData();
				void ReadSVMParams();				
				void TestDataSet();
				void SVMClassification(int startIndex, int stopIndex, int k_bias) ;
				void CalculateCumSum() ;
				void TestResult();
				void WriteToXml();
				void LoadDataFromXml();
				MATRIX *GetKernel(std::vector<Engine::ChargeDetermination::FeatureList> &vect_xtest, std::vector<Engine::ChargeDetermination::FeatureList> &vect_xsup);
				

				SVMTestData();
				~SVMTestData();
		};
	}
}
