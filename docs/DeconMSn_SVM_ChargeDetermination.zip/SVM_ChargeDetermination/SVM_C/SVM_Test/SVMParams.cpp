#include "clsSVM.h"

namespace Engine
{
	namespace ChargeDetermination
	{
		SVM_Parameters::SVM_Parameters(void)
		{
			mdbl_w0 = 0;
		}

		SVM_Parameters::~SVM_Parameters(void)
		{
		}
	}
}