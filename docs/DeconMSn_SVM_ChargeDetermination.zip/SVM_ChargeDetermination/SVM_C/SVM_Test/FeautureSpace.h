#include <iostream>
#include <vector>

namespace Engine
{
	namespace ChargeDetermination
	{
		class FeatureList
		{
			private:

				/*int mint_msN_scan_num;
				double mdbl_parent_mz;
				double mdbl_xscore2;
				double mdbl_xscore3;
				double mdbl_xscore_ratio;
				double mdbl_bscore2;
				double mdbl_bscore3;
				double mdbl_bscore_ratio;
				double mdbl_pk2_prob;
				double mdbl_pk3_prob;
				double mdbl_fscore2;
				double mdbl_fscore3;
				double mdbl_xscore2_CO;
				double mdbl_xscore3_CO;
				double mdbl_xscore2_H2O;
				double mdbl_xscore3_H2O;
				double mdbl_xscore2_NH3;
				double mdbl_xscore3_NH3;*/

				int mint_num_features;

				std::vector<double> mvect_features;

			public:

				FeatureList(void);

				~FeatureList(void);

				/*void InitValues(int scan_num, double parent_Mz, double x_score2, double x_score3, double x_score_ratio,
								double b_score2, double b_score3, double b_score_ratio, double pk2_prb, double pk3_prob,
								double fscore2, double fscore3, double x_score2_CO, double x_score3_CO, double x_score2_H2O, 
								double x_score3_H20, double x_score2_NH3, double x_score3_NH3 );*/
				void InitValues(std::vector<double> &features);

				void SetNumFeatures(int num_features);
				int GetNumFeatures();
				double GetValueAt(int index);
		};
	}
}

										

