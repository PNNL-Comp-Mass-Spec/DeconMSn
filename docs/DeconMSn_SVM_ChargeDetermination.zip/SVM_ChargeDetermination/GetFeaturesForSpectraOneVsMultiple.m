clc
clear all;
X = [];


cc_mass = 1.007825;
proton_mass = 1.00727638;
mCO = 27.9949141 ;
mH20 = 18.0105633;
mNH3 = 17.0265458;

chargeIndex = 1;
scanIndex = 2;
parentMZIndex = 3;



fid = fopen('C:\data\Dta\file_list.txt');
fout = fopen('C:\data\Dta\ExcelDocs\Training_Data.txt', 'wt');
%charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk2prob pk3prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];
filename = fgets(fid);

min_scan = 0;
max_scan = 0;
while filename ~= -1      
    fileCh = strcat(filename) ;
    fspectra = fopen(fileCh);
    line = fgets(fspectra);
    value = str2num(line);
    mass = value(1);
    charge = value(2);  
    scan = GetScanFromFilename(filename);
    if scan > max_scan
        max_scan = scan;
    end

    parent_mz = ((mass - proton_mass)/charge) + cc_mass ;  
    line = fgets(fspectra);
    % Read in the spectra
    index_mz = 1;
    Mz_list = [];
    Intensity_list = [];
    while(line ~= -1)
        value = str2num(line);
        Mz_list(index_mz) = value(1);
        Intensity_list(index_mz) = value(2) ;
        index_mz = index_mz + 1;
        line = fgets(fspectra);
    end
    line = fgets(fspectra);        


    % - X_score
    X_score2 = GetXScore(2, Mz_list, Intensity_list, parent_mz);        
    X_score3 = GetXScore(3, Mz_list, Intensity_list, parent_mz);                
    % - X_score ratio
    if (X_score2 ~= 0)
        X_score_ratio = X_score3/X_score2;
    else
        X_score_ratio = 0;
    end
    %- B_score 
     B_score2 = GetBScore(2, Mz_list, Intensity_list, parent_mz);
     B_score3 = GetBScore(3, Mz_list, Intensity_list, parent_mz);
    %- Peak Distribution
    distribution = GetPeakDistribution(Mz_list, Intensity_list, parent_mz);
    pk2prob = distribution(2)/sum(distribution);
    pk3prob = distribution(3)/sum(distribution) ;
    % - FisherScore
    F_score2 = GetFScore(2, distribution);        
    F_score3 = GetFScore(3, distribution);
    % - X_score from loss
    X_score2_CO = GetXScore(2, Mz_list, Intensity_list, parent_mz, mCO) ;
    X_score3_CO = GetXScore(3, Mz_list, Intensity_list, parent_mz, mCO);
    X_score2_H2O = GetXScore(2, Mz_list, Intensity_list, parent_mz, mH20) ;
    X_score3_H2O = GetXScore(3, Mz_list, Intensity_list, parent_mz, mH20) ;
    X_score2_NH3 = GetXScore(2, Mz_list, Intensity_list, parent_mz, mNH3) ;
    X_score3_NH3 = GetXScore(3, Mz_list, Intensity_list, parent_mz, mNH3) ;                

    Set = [charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk2prob pk3prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];
    

    fprintf(fout, '%d\t', Set(1));
    fprintf(fout, '%d\t', Set(2));
    for i = 2:size(Set,2)
        fprintf(fout, '%f\t', Set(i));
    end
    fprintf(fout, '\n');

    X = [X ; Set];           
   
    fclose(fspectra);    
    filename  = fgets(fid);    
end

fclose(fid) ;
fclose(fout);

% subtract mean - std_dv and save to training data
Ione = find(X(:, chargeIndex) == 1);
Imultiple = find(X(:, chargeIndex) ~= 1);

num_cols = size(X,2);
num_stdev = 3;

Xtrain = [];
ytrain = [];


feature_cs_one = X(Ione, scanIndex);
feature_cs_multiple = X(Imultiple, scanIndex);
feature_cs_one = feature_cs_one/max_scan;
feature_cs_multiple = feature_cs_multiple/max_scan;
Xtrain = [Xtrain, [feature_cs_one; feature_cs_multiple]];

feature_cs_one = X(Ione, parentMZIndex);
feature_cs_multiple = X(Imultiple, parentMZIndex);
Xtrain = [Xtrain, [feature_cs2; feature_cs3]];


for col_num  = 4: num_cols   
    feature_cs_one = X(I_one, col_num);
    feature_cs_multiple = X(I_multiple, col_num);
    
    feature_cs_one_filtered = zeros(size(feature_cs_one, 1), 1);
    feature_cs_multiple_filtered = zeros(size(feature_cs_multiple, 1), 1);
    
    meanFeature_cs_one = mean(feature_cs_one);
    meanFeature_cs_multiple = mean(feature_cs_multiple);

    stdFeature_cs_one = std(feature_cs_one);
    stdFeature_cs_multiple = std(feature_cs_multiple);

    i_one= find(abs(feature_cs_one - meanFeature_cs_one) < num_stdev*stdFeature_cs_one);
    i_multiple= find(abs(feature_cs3 - meanFeature_cs_multiple) < num_stdev*stdFeature_cs_multiple);

    feature_cs_one_filtered(i_one) = feature_cs_one(i_one);
    feature_cs_multiple_filtered(i_multiple) = feature_cs_multiple(i_multiple);

    Xtrain = [Xtrain, [feature_cs_one_filtered ; feature_cs_multiple_filtered]];
     
end

ytrain(1:size(Ione)) = 1;
ytrain(size(Ione):size(Xtrain)) = -1;
ytrain = ytrain';

save Human2_OneVsMultiple X Xtrain ytrain
%load Xapp;
%load yapp;
Xapp_OneVsMultiple = [] ; 
yapp_OneVsMultiple = [] ; 

Xapp_OneVsMultiple = [Xapp_OneVsMultiple;Xtrain];
yapp_OneVsMultiple = [yapp_OneVsMultiple;ytrain];
save Xapp_OneVsMultiple Xapp_OneVsMultiple
save yapp_OneVsMultiple yapp_OneVsMultiple

clear all
close all