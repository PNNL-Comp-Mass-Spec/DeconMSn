function out = GetPeakDistribution(mzs, intensities, parent_mz)


distribution  = [0 0 0 0];
for i = 1: size(mzs,2)  
    mz = mzs(i);
    if (mz <= parent_mz)
        distribution(1) = distribution(1) + 1;
    elseif ((mz > parent_mz) && (mz <= (2*parent_mz)))
        distribution(2) = distribution(2) + 1;
    elseif (mz > (2* parent_mz) && mz < (3 * parent_mz))
        distribution(3) = distribution(3) + 1;
    elseif (mz > (3* parent_mz) && mz < (4 * parent_mz))
        distribution(4) = distribution(4) + 1;
    end    
end

out =  distribution;
return

