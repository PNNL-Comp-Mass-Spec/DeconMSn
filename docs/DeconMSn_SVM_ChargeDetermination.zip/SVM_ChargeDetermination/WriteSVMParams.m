clear ; 
clc ;
load xtest
fout = fopen('C:\data\Dta\ExcelDocs\SVM_Params.dat', 'wt');

%(xtest,xsup,w,b,nbsv,kernel,kerneloption
[num_vectors, num_features] = size(xsup);

fprintf(fout, '@w');
fprintf(fout, '\n');
w_size = size(w,1);
for i = 1:w_size-1
    fprintf(fout, '%f ', w(i));        
end
fprintf(fout, '%f', w(w_size));        
fprintf(fout, '\n');

fprintf(fout, '@b') ; 
fprintf(fout, '\n');
b_size = size(b,1) ; 
for i = 1:b_size-1
    fprintf(fout, '%f ', b(i));        
end
fprintf(fout, '%f', b(b_size));        
fprintf(fout, '\n');


fprintf(fout, '@nbsv') ; 
fprintf(fout, '\n');
nbsv_size = size(nbsv,2) ; 
for i = 1:nbsv_size-1
    fprintf(fout, '%f ', nbsv(i));        
end
fprintf(fout, '%f', nbsv(nbsv_size));        
fprintf(fout, '\n');

fprintf(fout, '@xsup');
fprintf(fout, '\n');
for i = 1: num_vectors
    fprintf(fout, '%f ', xsup(i,[1:num_features-1]));        
    fprintf(fout, '%f', xsup(i,[num_features]));        
    fprintf(fout, '\n');
end

fout(close);
close all;
clear fout



