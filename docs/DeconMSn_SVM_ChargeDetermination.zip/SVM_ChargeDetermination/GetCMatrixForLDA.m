function [out1, out2, out3] =  GetCMatrixForLDA()

x2 = [];
x3 = [];
count2 = 0;
count3 = 0;
y = [2;3];
fid = fopen('Training_Set.txt');
fline = fgets(fid)

while fline ~= -1
    value = str2num(fline) ;
    if value(1) == 2
        x2 = [x2 ; value(2), value(3)];
        count2 = count2 + 1;
    elseif value(1) == 3
        x3 = [x3; value(2), value(3)] ;
        count3 = count3 + 1;
    else
        print 'Error';        
        out = 0;
        return;
    end
    fline = fgets(fid);
end





x = [x2 ; x3];

count = count2 + count3;

mu = mean(x);
mu2 = mean(x2);
mu3 = mean(x3);

mean_corrected_x2(:,1) = x2(:,1) - mu(1) ;
mean_corrected_x3(:,1) = x3(:,1) - mu(1) ;
mean_corrected_x2(:,2) = x2(:,2) - mu(2) ;
mean_corrected_x3(:,2) = x3(:,2) - mu(2) ;

Cov2 = ((mean_corrected_x2)'*(mean_corrected_x2))/count2 ;
Cov3 = ((mean_corrected_x3)'*(mean_corrected_x3))/count3 ;

C(1,1) = (count2/count) * Cov2(1,1) + (count3/count) * Cov2(1,1) ; 
C(1,2) = (count2/count) * Cov2(1,2) + (count3/count) * Cov2(1,2) ; 
C(2,1) = (count2/count) * Cov2(2,1) + (count3/count) * Cov2(2,1) ; 
C(2,2) = (count2/count) * Cov2(2,2) + (count3/count) * Cov2(2,2) ; 

P = [count2/count count3/count] ; 

fout = fopen('Results.txt', 'wt') ;
err_count = 0;
for i = 1: size(x2)
    fprintf(fout, '%d\t', 2);
    fprintf(fout, '%f\t', x2(i,1));
    fprintf(fout, '%f\t', x2(i,2));
    xk = x2(i,:);
    f2 = mu2*inv(C)*xk' - 0.5*mu2*inv(C)*mu2' + log(P(1)) ;
    f3 = mu3*inv(C)*xk' - 0.5*mu3*inv(C)*mu3' + log(P(2)) ;
    if (f2 > f3)
        fprintf(fout, '%d\n', 2);
    else
        err_count = err_count + 1;
        fprintf(fout, '%d\n', 3);
    end
end
   
err_count
err_count = 0;
for i = 1: size(x3)
    fprintf(fout, '%d\t', 3);
    fprintf(fout, '%f\t', x3(i,1));
    fprintf(fout, '%f\t', x3(i,2));
    xk = x3(i,:);
    f2 = mu2*inv(C)*xk' - 0.5*mu2*inv(C)*mu2' + log(P(1)) ;
    f3 = mu3*inv(C)*xk' - 0.5*mu3*inv(C)*mu3' + log(P(2)) ;
    if (f2 > f3)
        err_count = err_count + 1;
        fprintf(fout, '%d\n', 2);
    else
        fprintf(fout, '%d\n', 3);
    end
end

err_count
fclose(fout);

out1 = inv(C)
out2 = mu2
out3 = mu3
return