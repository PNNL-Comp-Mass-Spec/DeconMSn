function out = GetFScore(charge, pk_distribution)

fscore = 0;
x = [pk_distribution(2) pk_distribution(3)];
prob = x/sum(pk_distribution) ;
C = [8422 102.4;102.4 23.746] ;

x_T = x';
inv_C = inv(C);

if (charge == 2)
    mean2 = [202.54 0.31098];
    first_term = mean2*inv_C*x_T;
    second_term = mean2*inv_C*mean2';
    fscore = first_term - 0.5*second_term + prob(1);
end
if (charge == 3)
    mean3 = [254.84 14.152];
    first_term = mean3*inv_C*x_T;
    second_term = mean3*inv_C*mean3';
    fscore = first_term - 0.5*second_term + prob(2);
end

out = fscore;
return
    
