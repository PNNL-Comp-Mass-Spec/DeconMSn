load Xapp; 
load yapp ;
num_bins = 10 ; 

num_iterations = 1 ; 
num_stdev = 3 ; 

X = Xapp ; 


% chargeIndex = 1;
% scanIndex = 2;
% parentMzIndex = 3;
% Xscore2Index = 4;
% Xscore3Index = 5;
% XratioIndex = 6;
% Bscore2Index = 7;
% Bscore3Index = 8;
% pk2Index = 9;
% pk3Index = 10;
% F_score2  = 11;
% F_score3 = 12;
% X_score2_CO = 13;
% X_score3_CO = 14;
% X_score2_H2O  = 15;
% X_score3_H2O = 16;
% X_score2_NH3  = 17;
% X_score3_NH3 = 18;
% charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk1prob pk2prob pk3prob pk4prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];

col =  11
I1 = find(yapp == 1) ;
score_cs1 = X(I1, col) ;

I2 = find(yapp == 2) ;
score_cs2 = X(I2, col) ;

I3 = find(yapp == 3) ;
score_cs3 = X(I3, col) ;

I4 = find(yapp == 4) ;
score_cs4 = X(I4, col) ;


score_cs1_filtered  = score_cs1 ;
score_cs2_filtered = score_cs2 ; 
score_cs3_filtered = score_cs3 ; 
score_cs4_filtered = score_cs4 ; 

for iter_num = 1:num_iterations

    mean_cs1 = mean(score_cs1_filtered) ; 
    mean_cs2 = mean(score_cs2_filtered) ; 
    mean_cs3 = mean(score_cs3_filtered) ; 
    mean_cs4 = mean(score_cs4_filtered) ; 

    std_cs1  = std(score_cs1_filtered) ;
    std_cs2 = std(score_cs2_filtered) ; 
    std_cs3 = std(score_cs3_filtered) ; 
    std_cs4 = std(score_cs4_filtered) ; 

    I1 = find(abs(score_cs1_filtered - mean_cs1) < num_stdev * std_cs1) ; 
    I2 = find(abs(score_cs2_filtered - mean_cs2) < num_stdev * std_cs2) ; 
    I3 = find(abs(score_cs3_filtered - mean_cs3) < num_stdev * std_cs3) ; 
    I4 = find(abs(score_cs4_filtered - mean_cs4) < num_stdev * std_cs4) ; 

    score_cs1_filtered = score_cs1_filtered(I1) ; 
    score_cs2_filtered = score_cs2_filtered(I2) ; 
    score_cs3_filtered = score_cs3_filtered(I3) ; 
    score_cs4_filtered = score_cs4_filtered(I4) ; 
end

[n1, x1] = hist(score_cs1_filtered, num_bins) ; 
[n2, x2] = hist(score_cs2_filtered, num_bins) ;
[n3, x3] = hist(score_cs3_filtered, num_bins) ;
[n4, x4] = hist(score_cs4_filtered, num_bins) ;

if 1
%       plot(x1, n1/sum(n1), 'k-*') ; 
%       hold on ; 
   % subplot(3,2,6)
    plot(x2, n2/sum(n2), 'r-*') ;
    hold on ;   
    plot(x3, n3/sum(n3), 'b-*') ;
    hold on
%       hold on ;   
%        plot(x4, n4/sum(n4), 'g-*') ;
else
    plot(x1, n1/sum(n1), 'k-*') ; 
    hold on ;     
    plot(x2, cumsum(n2/sum(n2)), 'r-*') ;
    hold on ; 
    plot(x3, cumsum(n3/sum(n3)), 'b-*') ;
    hold on ;   
    plot(x4, n4/sum(n4), 'g-*') ;
end

% figure ; 
% [n1, x2] = hist(log(score_cs1_filtered+1), num_bins) ;
% [n2, x2] = hist(log(score_cs2_filtered+1), num_bins) ;
% [n3, x3] = hist(log(score_cs3_filtered+1), num_bins) ;
% % plot(x1, n1/sum(n1), 'k-*') ; 
% % hold on ;     
% plot(x2, n2/sum(n2), 'r-*') ;
% hold on ; 
% plot(x3, n3/sum(n3), 'b-*') ;