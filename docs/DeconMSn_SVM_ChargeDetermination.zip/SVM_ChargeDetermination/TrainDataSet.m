clc
close all
clear all

load Xapp
load yapp

[num_total,num_features] = size(Xapp) ;

I_charge1 = find(yapp == 1) ;
I_charge2 = find(yapp == 2) ;
I_charge3 = find(yapp == 3) ; 
I_charge4 = find(yapp == 4) ;

% As it already arranged
num_train = 1100;
[num_charge1, x] = size(I_charge1)
I1 = myrandint(num_train, 1, [1:num_charge1] , 'noreplace');
Itrain1 = I_charge1(I1) ; 
Xtrain1 = Xapp(Itrain1, :) ; 
ytrain1 = yapp(Itrain1, :) ; 

[num_charge2, x] = size(I_charge2)
I2 = myrandint(num_train, 1, [1:num_charge2] , 'noreplace');
Itrain2 = I_charge2(I2) ; 
Xtrain2 = Xapp(Itrain2, :) ; 
ytrain2 = yapp(Itrain2, :) ; 

[num_charge3, x] = size(I_charge3)
I3 = myrandint(num_train, 1, [1:num_charge3] , 'noreplace');
Itrain3 = I_charge3(I3) ; 
Xtrain3 = Xapp(Itrain3, :) ; 
ytrain3 = yapp(Itrain3, :) ; 

[num_charge4, x] = size(I_charge4)
I4 = myrandint(num_train, 1, [1:num_charge4] , 'noreplace');
Itrain4 = I_charge4(I4) ; 
Xtrain4 = Xapp(Itrain4, :) ; 
ytrain4 = yapp(Itrain4, :) ; 


xapp_train= [];
yapp_train = []; 

xapp_train = [Xtrain1; Xtrain2 ; Xtrain3; Xtrain4] ; 
yapp_train = [ytrain1; ytrain2 ; ytrain3; ytrain4] ; 

% Xtrain = [];
% ytrain = [];
% Xtrain = [Xtrain; Xapp(I_charge1, :); Xapp(I_charge2, :); Xapp(I_charge3, :); Xapp(I_charge4, :)];
% ytrain = [ytrain; yapp(I_charge1,:); yapp(I_charge2, :); yapp(I_charge3, :); yapp(I_charge4, :)];
% 
% 
% num_train = 5000;
% I_train = myrandint(num_train, 1, [1:num_total], 'noreplace');
% xapp_train = Xtrain(I_train, :) ;
% yapp_train = ytrain(I_train, :) ; 
% 
% ytrain(I_train, :) = -1;
% I_test = find(ytrain ~= -1) ;
% xtest = [];
% ytest = [];
% xtest = [xtest ; Xtrain(I_test, :)] ;
% ytest = [ytest ; ytrain(I_test, :)] ; 
%     
clear Xtrain1 Xtrain2 Xtrain3 Xtrain4;
clear ytrain1 ytrain2 ytrain3 ytrain4;
clear Xapp;
clear yapp;

for feature_num = 1:num_features
    min_feature = min(xapp_train(:, feature_num));
    min_test = min(xapp_train(:, feature_num));
    max_feature = max(xapp_train(:, feature_num));
    max_test = max(xapp_train(:, feature_num));
    if (max_feature - min_feature) > 0
        xapp_train(:, feature_num) = (xapp_train(:, feature_num) - min_feature)/(max_feature - min_feature);
    end
%     if (max_test - min_test) >0 
%         xtest(:, feature_num) = (xtest(:, feature_num) - min_test)/(max_test - min_test);
%     end
end

c = 1000;
lambda = 1e-7;
kerneloption=1;
kernel='gaussian';
verbose = 1 ;
nbclass = 4;
pack;
    
[xsup,w,b,nbsv,classifier]=svmmulticlassoneagainstone(xapp_train,yapp_train,nbclass,c,lambda,kernel,kerneloption,verbose);

save xtest_choose_equally