function out = GetBScore(charge, mzs, intensities, parentMz)
Bscore  = 0;
threshold = 5;
median_intensity = median(intensities) ;
intensities = intensities/median_intensity ;
intensities(intensities < threshold) = 0;

if (charge == 2)
    Ileft = find(mzs <= parentMz -1 );
    SumLeft = sum(intensities(Ileft));
    Iright = find(mzs >= parentMz+1 & mzs <= (2*parentMz));
    SumRight = sum(intensities(Iright));
    Itotal = find(mzs <= (2*parentMz));
    SumTotal = sum(intensities(Itotal));
    if SumTotal > 0
        Bscore = (SumLeft - SumRight)/SumTotal ; 
    end
end

if (charge == 3)
    Ileft = find(mzs <= parentMz -1 );
    SumLeft = sum(intensities(Ileft));
    Iright = find(mzs >= parentMz+1 & mzs < (3*parentMz));
    SumRight = sum (intensities(Iright));
     
    Itotal = find(mzs < 3*parentMz);
    SumTotal = sum(intensities(Itotal));
    
    if SumTotal > 0
        Bscore = (SumLeft - SumRight)/ SumTotal;
    end
end

out = abs(Bscore);
return;
    
    
    