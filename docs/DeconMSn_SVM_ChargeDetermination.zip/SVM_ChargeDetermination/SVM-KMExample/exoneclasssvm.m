%
%
%   One-Class SVM example
%


clear all
close all

n=100;
sigma=0.2;
[xapp,yapp]=dataset('gaussian',n,0,sigma);
nu=0.1;
kernel='gaussian';
kerneloption=0.33;
verbose=1;
[xsup,alpha,rho,pos]=svmoneclass(xapp,kernel,kerneloption,nu,verbose);

[xtest,xtest1,xtest2,nn]=DataGrid2D([-3:0.2:3],[-3:0.2:3]);

ypred=svmoneclassval(xtest,xsup,alpha,rho,kernel,kerneloption);
ypred=reshape(ypred,nn,nn);



%--------------- plotting
figure(1); 
clf; 
%contourf(xtest1,xtest2,ypred,50);shading flat;
hold on
[cc,hh]=contour(xtest1,xtest2,ypred,[-rho  0 rho],'k');
clabel(cc,hh); 
h1=plot(xapp(:,1),xapp(:,2),'+k'); 
set(h1,'LineWidth',2);
h3=plot(xsup(:,1),xsup(:,2),'ok'); 
set(h3,'LineWidth',2);
