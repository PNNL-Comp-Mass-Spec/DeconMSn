
[ypred,maxi] = svmmultivaloneagainstone(xtest,xsup,w,b,nbsv,kernel,kerneloption);

load X
X_temp = X ; 
fid = fopen('C:\data\Dta\file_list.txt');
fout = fopen('C:\data\Dta\ExcelDocs\Training_Data.txt', 'wt');
%charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk1_prob pk2prob pk3prob pk4_prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];
filename = fgets(fid);

min_scan = 0;
max_scan = 0;
while filename ~= -1      
    fileCh = strcat(filename) ;
    fspectra = fopen(fileCh);
    line = fgets(fspectra);
    value = str2num(line);
    mass = value(1);
    charge = value(2);  
    if charge > 1
        scan = GetScanFromFilename(filename);        
        I = find (X_temp(:,2) == scan) ; 
        X_temp(I,1) = charge ; 
    end
    fclose(fspectra);    
    filename  = fgets(fid);    
end

        
    
    

        
        