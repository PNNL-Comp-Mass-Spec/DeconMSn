clc
clear all;
X = [];


cc_mass = 1.007825;
proton_mass = 1.00727638;
mCO = 27.9949141 ;
mH20 = 18.0105633;
mNH3 = 17.0265458;

chargeIndex = 1;
scanIndex = 2;
parentMZIndex = 3;



fid = fopen('C:\data\Dta\validate_results\file_list.txt');
%fout = fopen('C:\data\Dta\ExcelDocs\Training_Data.txt', 'wt');
%charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk1_prob pk2prob pk3prob pk4_prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];
filename = fgets(fid);
scan = GetScanFromFilename(filename);
min_scan = scan;
max_scan = 0;
while filename ~= -1      
    fileCh = strcat(filename) ;
    fspectra = fopen(fileCh);
    line = fgets(fspectra);
    value = str2num(line);
    mass = value(1);
    charge = value(2);  
    scan = GetScanFromFilename(filename);
    sprintf ('Processing scan # %d', scan)  
    if scan > max_scan
        max_scan = scan;
    end
    if scan < min_scan
        min_scan = scan;
    end
    parent_mz = ((mass - proton_mass)/charge) + cc_mass ;  
    line = fgets(fspectra);
    % Read in the spectra
    index_mz = 1;
    Mz_list = [];
    Intensity_list = [];
    while(line ~= -1)
        value = str2num(line);
        Mz_list(index_mz) = value(1);
        Intensity_list(index_mz) = value(2) ;
        index_mz = index_mz + 1;
        line = fgets(fspectra);
    end
    line = fgets(fspectra);      

    % - X_score
    X_score2 = GetXScore(2, Mz_list, Intensity_list, parent_mz);        
    X_score3 = GetXScore(3, Mz_list, Intensity_list, parent_mz);                
    % - X_score ratio
    if (X_score2 ~= 0)
        X_score_ratio = X_score3/X_score2;
    else
        X_score_ratio = 0;
    end
    %- B_score 
     B_score2 = GetBScore(2, Mz_list, Intensity_list, parent_mz);
     B_score3 = GetBScore(3, Mz_list, Intensity_list, parent_mz);
    %- Peak Distribution
    distribution = GetPeakDistribution(Mz_list, Intensity_list, parent_mz);
    pk1prob = distribution(1)/sum(distribution) ;
    pk2prob = distribution(2)/sum(distribution);
    pk3prob = distribution(3)/sum(distribution) ;
    pk4prob = distribution(4)/sum(distribution) ;
    % - FisherScore
    F_score2 = GetFScore(2, distribution);        
    F_score3 = GetFScore(3, distribution);
    % - X_score from loss
    X_score2_CO = GetXScore(2, Mz_list, Intensity_list, parent_mz, mCO) ;
    X_score3_CO = GetXScore(3, Mz_list, Intensity_list, parent_mz, mCO);
    X_score2_H2O = GetXScore(2, Mz_list, Intensity_list, parent_mz, mH20) ;
    X_score3_H2O = GetXScore(3, Mz_list, Intensity_list, parent_mz, mH20) ;
    X_score2_NH3 = GetXScore(2, Mz_list, Intensity_list, parent_mz, mNH3) ;
    X_score3_NH3 = GetXScore(3, Mz_list, Intensity_list, parent_mz, mNH3) ;           

    Set = [charge scan parent_mz X_score2 X_score3 X_score_ratio B_score2 B_score3 pk1prob pk2prob pk3prob pk4prob F_score2 F_score3 X_score2_CO X_score3_CO X_score2_H2O X_score3_H2O X_score2_NH3 X_score3_NH3];


%         fprintf(fout, '%d\t', Set(1));
%         fprintf(fout, '%d\t', Set(2));
%         for i = 2:size(Set,2)
%             fprintf(fout, '%f\t', Set(i));
%         end
%         fprintf(fout, '\n');

    X = [X ; Set];           
    fclose(fspectra);    
    filename  = fgets(fid);    
end

fclose(fid) ;
%fclose(fout);


% % subtract mean - std_dv and save to training data
% I1 = find(X(:, chargeIndex) == 1) ;
% I2 = find(X(:, chargeIndex) == 2);
% I3 = find(X(:, chargeIndex) == 3);
% I4 = find(X(:, chargeIndex) == 4);
% 
% num_cols = size(X,2);
% num_stdev = 3;
% 
% Xtrain = [];
% ytrain = [];
% 
% feature_cs1 = X(I1, scanIndex);
% feature_cs2 = X(I2, scanIndex);
% feature_cs3 = X(I3, scanIndex);
% feature_cs4 = X(I4, scanIndex);
% 
% feature_cs1 = (feature_cs1-min_scan)/(max_scan-min_scan);
% feature_cs2 = (feature_cs2-min_scan)/(max_scan-min_scan);
% feature_cs3 = (feature_cs3-min_scan)/(max_scan-min_scan);
% feature_cs4 = (feature_cs4-min_scan)/(max_scan-min_scan);
% 
% Xtrain = [Xtrain, [feature_cs1; feature_cs2; feature_cs3;feature_cs4]];
% 
% feature_cs1 = X(I1, parentMZIndex);
% feature_cs2 = X(I2, parentMZIndex);
% feature_cs3 = X(I3, parentMZIndex);
% feature_cs4 = X(I4, parentMZIndex);
% 
% Xtrain = [Xtrain, [feature_cs1; feature_cs2; feature_cs3;feature_cs4]];
% 
% for col_num  = 4: num_cols   
%     feature_cs1 = X(I1, col_num);
%     feature_cs2 = X(I2, col_num);
%     feature_cs3 = X(I3, col_num);
%     feature_cs4 = X(I4, col_num);    
%     
%     feature_cs1_filtered = zeros(size(feature_cs1, 1), 1);
%     feature_cs2_filtered = zeros(size(feature_cs2, 1), 1);
%     feature_cs3_filtered = zeros(size(feature_cs3, 1), 1);
%     feature_cs4_filtered = zeros(size(feature_cs4, 1), 1);
%     
%     meanFeature_cs1 = mean(feature_cs1) ;
%     meanFeature_cs2 = mean(feature_cs2);
%     meanFeature_cs3 = mean(feature_cs3);
%     meanFeature_cs4 = mean(feature_cs4);
%     
%     stdFeature_cs1 = std(feature_cs1);
%     stdFeature_cs2 = std(feature_cs2);
%     stdFeature_cs3 = std(feature_cs3);
%     stdFeature_cs4 = std(feature_cs4);
% 
%     i1= find(abs(feature_cs1 - meanFeature_cs1) < num_stdev*stdFeature_cs1);
%     i2= find(abs(feature_cs2 - meanFeature_cs2) < num_stdev*stdFeature_cs2);
%     i3= find(abs(feature_cs3 - meanFeature_cs3) < num_stdev*stdFeature_cs3);
%     i4= find(abs(feature_cs4 - meanFeature_cs4) < num_stdev*stdFeature_cs4);
% 
%     feature_cs1_filtered(i1) = feature_cs1(i1);
%     feature_cs2_filtered(i2) = feature_cs2(i2);
%     feature_cs3_filtered(i3) = feature_cs3(i3);
%     feature_cs4_filtered(i4) = feature_cs4(i4);
% 
%     Xtrain = [Xtrain, [feature_cs1; feature_cs2; feature_cs3; feature_cs4]];
%      
% end
% 
% ytrain1 = zeros(size(I1,1),1);
% ytrain2 = zeros(size(I2,1),1);
% ytrain3 = zeros(size(I3,1),1);
% ytrain4 = zeros(size(I4,1),1);
% 
% ytrain1(1:size(I1),1) = 1;
% ytrain2(1:size(I2),1) = 2;
% ytrain3(1:size(I3),1) = 3;
% ytrain4(1:size(I4),1) = 4;
% 
% ytrain = [ytrain1; ytrain2; ytrain3; ytrain4];
% 
% 
% 
% save Shew1 X Xtrain ytrain
% % load Xapp;
% % load yapp;
% % Xapp = []; %uncomment for first time
% % yapp = [];
% % Xapp = [Xapp;Xtrain];
% % yapp = [yapp;ytrain];
% % save Xapp Xapp
% % save yapp yapp
% 
% clear all
% close all